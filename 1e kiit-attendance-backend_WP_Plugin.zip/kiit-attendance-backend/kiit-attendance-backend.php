<?php
/*
Plugin Name: KIIT Attendance Backend (Token API + Debug)
Description: Stores KIIT Attendance App data in WordPress and exposes REST API with token auth. Includes ping + token-test endpoints for debugging.
Version: 1.2
Author: sekr.in
*/

if ( ! defined('ABSPATH') ) exit;

define('KIIT_ATT_OPTION_DATA',  'kiit_att_data_json');
define('KIIT_ATT_OPTION_TOKEN', 'kiit_att_api_token');

register_activation_hook(__FILE__, function () {
    $token = get_option(KIIT_ATT_OPTION_TOKEN, '');
    if ( empty($token) ) {
        $token = wp_generate_password(40, false, false);
        update_option(KIIT_ATT_OPTION_TOKEN, $token);
    }
});

add_action('admin_menu', function () {
    add_options_page(
        'KIIT Attendance Backend',
        'KIIT Attendance Backend',
        'manage_options',
        'kiit-att-backend',
        'kiit_att_render_admin_page'
    );
});

function kiit_att_render_admin_page() {
    if ( ! current_user_can('manage_options') ) return;

    if ( isset($_POST['kiit_att_rotate_token']) ) {
        check_admin_referer('kiit_att_rotate_token_action');
        $new = wp_generate_password(40, false, false);
        update_option(KIIT_ATT_OPTION_TOKEN, $new);
        echo '<div class="notice notice-success"><p><strong>Token rotated.</strong> Update your HTML with the new token.</p></div>';
    }

    $token = get_option(KIIT_ATT_OPTION_TOKEN, '');
    $base  = home_url('/wp-json/kiit-att/v1');
    $data  = esc_url($base . '/data');
    $ping  = esc_url($base . '/ping');
    $ttest = esc_url($base . '/token-test');

    ?>
    <div class="wrap">
      <h1>KIIT Attendance Backend (Token API + Debug)</h1>

      <h2>Endpoints</h2>
      <ul>
        <li><strong>Ping:</strong> <code><?php echo $ping; ?></code></li>
        <li><strong>Data:</strong> <code><?php echo $data; ?></code></li>
        <li><strong>Token test:</strong> <code><?php echo $ttest; ?></code> (requires token header)</li>
      </ul>

      <h2>API Token (keep this secret)</h2>
      <p>Put this into your <code>index.html</code> as <code>REMOTE_API_TOKEN</code>:</p>
      <p style="font-size:16px;"><code><?php echo esc_html($token); ?></code></p>

      <form method="post" style="margin-top:12px;">
        <?php wp_nonce_field('kiit_att_rotate_token_action'); ?>
        <button class="button button-secondary" name="kiit_att_rotate_token" value="1" type="submit">
          Rotate Token
        </button>
      </form>

      <hr />
      <h2>How to test quickly</h2>
      <ol>
        <li>Open <code><?php echo $ping; ?></code> — must show JSON (not blank).</li>
        <li>Open <code><?php echo $data; ?></code> — shows JSON with <code>classes</code>.</li>
        <li>From your app page, save something and refresh <code><?php echo $data; ?></code> — it should show your stored data.</li>
      </ol>
    </div>
    <?php
}

/**
 * CORS (because your app is http://sekr.in but API is https://sekr.in → different origin)
 */
add_action('rest_api_init', function () {
    add_filter('rest_pre_serve_request', function ($served, $result, $request, $server) {

        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

        $allowed = array(
            'http://sekr.in',
            'https://sekr.in',
            'http://www.sekr.in',
            'https://www.sekr.in',
        );

        if ( in_array($origin, $allowed, true) ) {
            header('Access-Control-Allow-Origin: ' . $origin);
        }

        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-KIIT-TOKEN');
        header('Access-Control-Max-Age: 86400');

        return $served;
    }, 10, 4);
});

/**
 * Routes:
 *  GET  /ping        -> always returns JSON
 *  GET  /data        -> returns stored JSON object (never null)
 *  POST /data        -> saves JSON (token required)
 *  GET  /token-test  -> returns JSON if token correct (token required)
 */
add_action('rest_api_init', function () {

    register_rest_route('kiit-att/v1', '/ping', array(
        'methods'             => 'GET',
        'callback'            => function () {
            return new WP_REST_Response(array(
                'ok' => true,
                'plugin' => 'KIIT Attendance Backend',
                'version' => '1.2',
                'time' => current_time('mysql'),
            ), 200);
        },
        'permission_callback' => '__return_true',
    ));

    register_rest_route('kiit-att/v1', '/token-test', array(
        'methods'             => 'GET',
        'callback'            => function () {
            return new WP_REST_Response(array(
                'ok' => true,
                'token' => 'valid',
                'time' => current_time('mysql'),
            ), 200);
        },
        'permission_callback' => 'kiit_att_check_token',
    ));

    register_rest_route('kiit-att/v1', '/data', array(

        array(
            'methods'             => 'GET',
            'callback'            => 'kiit_att_get_data',
            'permission_callback' => '__return_true',
        ),

        array(
            'methods'             => 'POST',
            'callback'            => 'kiit_att_post_data',
            'permission_callback' => 'kiit_att_check_token',
        ),

        array(
            'methods'             => 'OPTIONS',
            'callback'            => function () { return new WP_REST_Response(null, 200); },
            'permission_callback' => '__return_true',
        ),
    ));
});

function kiit_att_check_token( WP_REST_Request $request ) {
    $serverToken = get_option(KIIT_ATT_OPTION_TOKEN, '');

    $headerToken = $request->get_header('x-kiit-token');
    $queryToken  = $request->get_param('token'); // optional fallback

    $clientToken = '';
    if ( ! empty($headerToken) ) $clientToken = $headerToken;
    if ( empty($clientToken) && ! empty($queryToken) ) $clientToken = $queryToken;

    if ( empty($serverToken) || empty($clientToken) ) return false;

    return hash_equals($serverToken, $clientToken);
}

function kiit_att_get_data( WP_REST_Request $request ) {
    $json = get_option(KIIT_ATT_OPTION_DATA, '');

    // Always return a JSON OBJECT (never null) to avoid "blank page" confusion.
    if ( empty($json) ) {
        return new WP_REST_Response(array(
            'classes' => new stdClass(),
            'currentClassKey' => 'Section A',
            'appSettings' => new stdClass(),
            'savedAt' => null,
            '__empty' => true
        ), 200);
    }

    $decoded = json_decode($json, true);
    if ( json_last_error() !== JSON_ERROR_NONE || ! is_array($decoded) ) {
        // Corrupted stored JSON → return empty structure
        return new WP_REST_Response(array(
            'classes' => new stdClass(),
            'currentClassKey' => 'Section A',
            'appSettings' => new stdClass(),
            'savedAt' => null,
            '__empty' => true,
            '__error' => 'stored_json_corrupt'
        ), 200);
    }

    return new WP_REST_Response($decoded, 200);
}

function kiit_att_post_data( WP_REST_Request $request ) {
    $data = $request->get_json_params();

    if ( empty($data) || ! is_array($data) ) {
        return new WP_REST_Response(array('error' => 'Invalid or empty JSON body'), 400);
    }

    if ( ! isset($data['classes']) || ! is_array($data['classes']) ) {
        return new WP_REST_Response(array('error' => 'Missing or invalid "classes" field'), 400);
    }

    $encoded = wp_json_encode($data);
    if ( false === $encoded ) {
        return new WP_REST_Response(array('error' => 'Failed to encode JSON'), 500);
    }

    update_option(KIIT_ATT_OPTION_DATA, $encoded);

    return new WP_REST_Response(array(
        'status' => 'ok',
        'savedAt' => current_time('mysql')
    ), 200);
}